# LOCKDOWN Sprite Production Pipeline

Complete toolkit for generating, separating, and integrating paired grappling sprites.

## Quick Start

1. Read `docs/MASTER_PLAN.md` — the full step-by-step guide
2. Generate sprites using prompts in `prompts/ALL_PROMPTS.md`
3. Run the separation pipeline: `python scripts/separate_sprites.py`
4. Verify with preview: `python scripts/preview_anchors.py`
5. Integrate with `scripts/anchor_renderer.js`

## Setup

```bash
pip install Pillow numpy scikit-learn scipy
```

## File Structure

```
prompts/ALL_PROMPTS.md      — All ChatGPT generation prompts
scripts/separate_sprites.py — AI sprite separation + anchor detection
scripts/preview_anchors.py  — Visual verification tool
scripts/anchor_renderer.js  — Game engine anchor alignment system
docs/MASTER_PLAN.md         — Complete step-by-step production plan
```
