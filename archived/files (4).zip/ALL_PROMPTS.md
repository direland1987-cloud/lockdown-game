# LOCKDOWN — Complete ChatGPT Sprite Generation Prompts

> **IMPORTANT**: Before using these prompts, verify the character descriptions below match
> your existing sprites from previous generation sessions. If Marcus's shorts are a different
> colour or Yuki's hair is different, update the CHARACTER LOCK sections to match what you
> already have. Consistency with your existing assets is critical.

---

## CHARACTER LOCKS (Copy these into every prompt)

### Marcus "The Bull" Reyes — Character Lock
```
FIGHTER A — Marcus "The Bull" Reyes:
- Stocky, powerful heavyweight build (5'10", 220 lbs), wide shoulders, thick neck
- Latino, medium-brown skin tone
- Short buzzed dark hair, squared jaw, intense focused expression
- Wearing black fight shorts with red accent stripe down each side
- No shirt (no-gi), bare chest showing muscular build
- Short black fingerless MMA gloves
- Small bull tattoo on left shoulder
```

### Yuki "Spider" Tanaka — Character Lock
```
FIGHTER B — Yuki "Spider" Tanaka:
- Lean, wiry, flexible build (5'8", 155 lbs), long limbs relative to torso
- Japanese, light skin tone
- Messy medium-length black hair, sharp features, calm analytical expression
- Wearing dark navy compression rash guard with subtle spider web pattern on sleeves
- Navy fight shorts with white side panels
- Short black fingerless MMA gloves
- Lean defined muscles, not bulky
```

### Style Lock (Include in EVERY prompt)
```
STYLE: CPS2 Capcom arcade pixel art, 16-bit era aesthetic like Street Fighter Alpha or
Marvel vs Capcom. Bold outlines, clean readable silhouettes, limited colour palette with
strong contrast. Side-on fighting game perspective (3/4 view showing both fighters' faces
and bodies). Transparent background. Resolution suitable for 128-160px sprite display.
Single frame, no animation sheet.
```

---

## SECTION A: PAIRED GRAPPLING POSITIONS (8 Prompts)

These are the core sprites. Generate each one 3–5 times in ChatGPT and pick the best result.

---

### A1 — Closed Guard

```
Create a CPS2 Capcom arcade-style pixel art sprite of two fighters in a CLOSED GUARD
position in no-gi Brazilian Jiu-Jitsu.

FIGHTER A (INSIDE GUARD — on top, kneeling upright):
- Stocky, powerful heavyweight build, wide shoulders, thick neck
- Latino, medium-brown skin tone
- Short buzzed dark hair, squared jaw, intense focused expression
- Wearing black fight shorts with red accent stripe down each side
- Bare chest, muscular build, small bull tattoo on left shoulder
- Kneeling upright between Fighter B's legs, hands on Fighter B's torso/hips trying to posture up
- Weight sitting back slightly, good posture

FIGHTER B (PLAYING GUARD — on bottom, on their back):
- Lean, wiry build, long limbs
- Japanese, light skin tone
- Messy medium-length black hair, calm expression
- Dark navy compression rash guard with spider web pattern on sleeves
- Navy fight shorts with white side panels
- Lying on their back, LEGS WRAPPED AROUND Fighter A's waist with ankles locked behind Fighter A's back
- Hands gripping Fighter A's wrists or collar tie, pulling them down
- Hips elevated slightly, engaged guard

CRITICAL CONTACT POINTS — these MUST be visually connected with NO gaps:
- Fighter B's legs fully wrapped around Fighter A's waist, ankles crossed
- Fighter A's knees on the ground on either side of Fighter B's hips
- Fighter B's hands gripping Fighter A's arms
- Torsos close together

STYLE: CPS2 Capcom arcade pixel art, 16-bit era, Street Fighter Alpha aesthetic. Bold
outlines, clean silhouettes, limited colour palette, strong contrast. Side-on 3/4 fighting
game perspective. Transparent background. Both fighters clearly distinguishable.
Single frame, no animation sheet.
```

---

### A2 — Open Guard

```
Create a CPS2 Capcom arcade-style pixel art sprite of two fighters in an OPEN GUARD
position in no-gi Brazilian Jiu-Jitsu.

FIGHTER A (STANDING/KNEELING IN OPEN GUARD — on top):
- Stocky, powerful heavyweight build, wide shoulders, thick neck
- Latino, medium-brown skin tone
- Short buzzed dark hair, squared jaw
- Black fight shorts with red accent stripe, bare chest, bull tattoo on left shoulder
- Standing or kneeling in a low crouch, leaning forward slightly
- Hands on Fighter B's knees/shins trying to pass, or gripping ankles

FIGHTER B (PLAYING OPEN GUARD — on bottom):
- Lean, wiry build, long limbs
- Japanese, light skin tone, messy black hair
- Navy compression rash guard with spider web sleeves, navy shorts with white panels
- Lying on their back, hips angled toward Fighter A
- FEET ON Fighter A's hips or biceps (butterfly hooks or feet-on-hips guard)
- Hands gripping Fighter A's wrists or reaching for collar ties
- Active, dynamic position — not flat on back, hips alive

CRITICAL CONTACT POINTS:
- Fighter B's feet pressing against Fighter A's hips/biceps — clear physical contact
- Fighter B's hands gripping Fighter A's wrists or arms
- Distance between torsos (this is open guard — some space between them)

STYLE: CPS2 Capcom arcade pixel art, 16-bit era, Street Fighter Alpha aesthetic. Bold
outlines, clean silhouettes, limited colour palette, strong contrast. Side-on 3/4 fighting
game perspective. Transparent background. Single frame.
```

---

### A3 — Half Guard

```
Create a CPS2 Capcom arcade-style pixel art sprite of two fighters in HALF GUARD
position in no-gi Brazilian Jiu-Jitsu.

FIGHTER A (IN HALF GUARD — on top, passing):
- Stocky heavyweight build, wide shoulders, thick neck
- Latino, medium-brown skin, buzzed dark hair
- Black fight shorts with red stripe, bare chest, bull tattoo left shoulder
- On top, chest pressing down on Fighter B, body angled diagonally
- One leg free, one leg trapped between Fighter B's legs
- Driving weight forward with crossface (forearm across Fighter B's jaw) or underhook

FIGHTER B (PLAYING HALF GUARD — on bottom):
- Lean wiry build, long limbs
- Japanese, light skin, messy black hair
- Navy rash guard with spider web sleeves, navy shorts white panels
- On their back/side, turned slightly toward Fighter A
- BOTH LEGS wrapped around ONE of Fighter A's legs (trapping it between their thighs)
- One arm fighting for underhook on Fighter A's far side, other hand on Fighter A's head/neck
- Knee shield may be visible across Fighter A's chest/hip

CRITICAL CONTACT POINTS:
- Fighter B's legs locked around Fighter A's single leg — intertwined, no gap
- Chest-to-chest/chest-to-shoulder contact (top player pressing)
- Fighter B's underhook arm connected to Fighter A's body
- Fighter A's crossface arm across Fighter B's face/neck

STYLE: CPS2 Capcom arcade pixel art, 16-bit era, Street Fighter Alpha aesthetic. Bold
outlines, clean silhouettes, limited colour palette, strong contrast. Side-on 3/4 fighting
game perspective. Transparent background. Single frame.
```

---

### A4 — Side Control

```
Create a CPS2 Capcom arcade-style pixel art sprite of two fighters in SIDE CONTROL
position in no-gi Brazilian Jiu-Jitsu.

FIGHTER A (IN SIDE CONTROL — on top, controlling):
- Stocky heavyweight build, wide shoulders, thick neck
- Latino, medium-brown skin, buzzed dark hair
- Black fight shorts with red stripe, bare chest, bull tattoo left shoulder
- Lying PERPENDICULAR across Fighter B's chest (T-position, 90 degree angle)
- Chest heavy on Fighter B's chest, hips low and sprawled
- Near arm under Fighter B's head (crossface), far arm controlling Fighter B's far hip
- Knees NOT between Fighter B's legs — both knees on the same side

FIGHTER B (STUCK IN SIDE CONTROL — on bottom, pinned):
- Lean wiry build, long limbs
- Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Flat on their back, arms trying to frame against Fighter A's neck/shoulder
- Legs flat or slightly bent but FREE (not trapped, this is side control not mount)
- Head turned away from Fighter A due to crossface pressure
- Defensive posture — elbows tight, trying to create space

CRITICAL CONTACT POINTS:
- Fighter A's chest HEAVY on Fighter B's chest — full weight, no gap
- Fighter A's arm under Fighter B's head (crossface)
- Perpendicular body angle (T-shape when viewed from above)
- Fighter A's hips low and tight against Fighter B's near hip

STYLE: CPS2 Capcom arcade pixel art, 16-bit era, Street Fighter Alpha aesthetic. Bold
outlines, clean silhouettes, limited colour palette, strong contrast. Side-on 3/4 fighting
game perspective. Transparent background. Single frame.
```

---

### A5 — Mount

```
Create a CPS2 Capcom arcade-style pixel art sprite of two fighters in FULL MOUNT
position in no-gi Brazilian Jiu-Jitsu.

FIGHTER A (IN MOUNT — on top, dominant):
- Stocky heavyweight build, wide shoulders, thick neck
- Latino, medium-brown skin, buzzed dark hair
- Black fight shorts with red stripe, bare chest, bull tattoo left shoulder
- SITTING ON Fighter B's torso/stomach, straddling them
- Knees on the ground on either side of Fighter B's ribs
- Sitting upright or leaning forward with hands on Fighter B's chest/shoulders
- Dominant, controlling posture — heavy hips

FIGHTER B (STUCK IN MOUNT — on bottom, pinned):
- Lean wiry build, long limbs
- Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Flat on their back with Fighter A sitting on top of them
- Arms up trying to frame/push against Fighter A's chest or hips
- Legs flat on ground, possibly trying to bridge (hips slightly raised)
- Defensive, trying to escape

CRITICAL CONTACT POINTS:
- Fighter A's hips/seat DIRECTLY ON Fighter B's stomach — full weight sitting
- Fighter A's knees on ground squeezing Fighter B's ribs on both sides
- Fighter A's hands pressing on Fighter B's chest or posting on ground
- Fighter B's hands pushing against Fighter A's body

STYLE: CPS2 Capcom arcade pixel art, 16-bit era, Street Fighter Alpha aesthetic. Bold
outlines, clean silhouettes, limited colour palette, strong contrast. Side-on 3/4 fighting
game perspective. Transparent background. Single frame.
```

---

### A6 — Back Mount (Back Control)

```
Create a CPS2 Capcom arcade-style pixel art sprite of two fighters in BACK MOUNT
(back control) position in no-gi Brazilian Jiu-Jitsu.

FIGHTER A (HAS THE BACK — behind, controlling):
- Stocky heavyweight build, wide shoulders, thick neck
- Latino, medium-brown skin, buzzed dark hair
- Black fight shorts with red stripe, bare chest, bull tattoo left shoulder
- Sitting BEHIND Fighter B, chest against Fighter B's back
- BOTH HOOKS IN — feet/heels hooked inside Fighter B's inner thighs
- Arms in SEATBELT grip — one arm over Fighter B's shoulder, one arm under opposite armpit, hands clasped on Fighter B's chest
- Head beside Fighter B's head, looking over their shoulder

FIGHTER B (BACK TAKEN — being controlled from behind):
- Lean wiry build, long limbs
- Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Seated upright or leaning slightly forward, Fighter A attached to their back
- Hands gripping Fighter A's seatbelt arms, trying to strip the grip
- Legs extended forward with Fighter A's hooks inside their thighs
- Defensive, chin tucked to prevent choke

CRITICAL CONTACT POINTS:
- Fighter A's chest FLUSH against Fighter B's back — no gap
- Seatbelt arms wrapped around Fighter B's torso, hands clasped
- Both hooks (Fighter A's feet) inside Fighter B's thighs
- Head-to-head contact (side by side)

STYLE: CPS2 Capcom arcade pixel art, 16-bit era, Street Fighter Alpha aesthetic. Bold
outlines, clean silhouettes, limited colour palette, strong contrast. Side-on 3/4 fighting
game perspective showing the wrap-around position clearly. Transparent background. Single frame.
```

---

### A7 — Turtle / Front Headlock

```
Create a CPS2 Capcom arcade-style pixel art sprite of two fighters in TURTLE / FRONT
HEADLOCK position in no-gi Brazilian Jiu-Jitsu.

FIGHTER A (ON TOP — sprawled, controlling):
- Stocky heavyweight build, wide shoulders, thick neck
- Latino, medium-brown skin, buzzed dark hair
- Black fight shorts with red stripe, bare chest, bull tattoo left shoulder
- Sprawled on top of Fighter B who is turtled up
- One arm wrapped around Fighter B's neck (front headlock/guillotine grip)
- Other arm reaching over Fighter B's back or controlling their far arm
- Chest draped over Fighter B's upper back, hips heavy, legs sprawled back

FIGHTER B (IN TURTLE — on hands and knees, defensive):
- Lean wiry build, long limbs
- Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- ON HANDS AND KNEES (turtle position), curled up defensively
- Head down, tucked — Fighter A's arm around their neck
- Elbows tight, knees under them, protecting against being flattened
- Compact, defensive ball position

CRITICAL CONTACT POINTS:
- Fighter A's arm AROUND Fighter B's neck — fully encircling, no gap
- Fighter A's chest on Fighter B's upper back
- Fighter A's hips heavy on Fighter B's lower back/hips
- Fighter B clearly on all fours with Fighter A draped over top

STYLE: CPS2 Capcom arcade pixel art, 16-bit era, Street Fighter Alpha aesthetic. Bold
outlines, clean silhouettes, limited colour palette, strong contrast. Side-on 3/4 fighting
game perspective. Transparent background. Single frame.
```

---

### A8 — Standing Clinch

```
Create a CPS2 Capcom arcade-style pixel art sprite of two fighters in a STANDING CLINCH
position in no-gi Brazilian Jiu-Jitsu / MMA.

FIGHTER A (LEFT SIDE — clinch aggressor):
- Stocky heavyweight build, wide shoulders, thick neck
- Latino, medium-brown skin, buzzed dark hair
- Black fight shorts with red stripe, bare chest, bull tattoo left shoulder
- Standing, feet planted shoulder-width apart in fighting stance
- One arm with UNDERHOOK under Fighter B's armpit
- Other hand gripping behind Fighter B's neck (collar tie / Thai clinch)
- Leaning head against Fighter B's head, driving forward

FIGHTER B (RIGHT SIDE — clinch defensive):
- Lean wiry build, long limbs
- Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Standing, slightly bent at waist being pulled in by clinch
- One arm with overhook/whizzer over Fighter A's underhook arm
- Other hand fighting for wrist control or posting on Fighter A's shoulder
- Feet staggered, resisting the pull

CRITICAL CONTACT POINTS:
- Head-to-head contact (foreheads or temples touching)
- Underhook arm DEEP under armpit — full arm contact
- Collar tie hand behind neck — connected
- Chests close but not fully flush (standing grappling distance)

STYLE: CPS2 Capcom arcade pixel art, 16-bit era, Street Fighter Alpha aesthetic. Bold
outlines, clean silhouettes, limited colour palette, strong contrast. Side-on 3/4 fighting
game perspective. Transparent background. Single frame.
```

---

## SECTION B: SOLO CHARACTER SPRITES (14 Prompts)

These are standalone single-character sprites for moments when fighters are NOT entangled.

### Style Prefix (use for all Section B prompts):
```
Create a CPS2 Capcom arcade-style pixel art sprite. 16-bit era aesthetic like Street
Fighter Alpha. Bold outlines, clean silhouettes, limited colour palette, strong contrast.
Side-on 3/4 fighting game perspective. Transparent background. Single character, single
frame, no animation sheet.
```

---

### B1 — Marcus Idle Stance
```
[STYLE PREFIX]

Single fighter in relaxed fighting stance:
- Stocky heavyweight build (5'10", 220 lbs), wide shoulders, thick neck
- Latino, medium-brown skin, short buzzed dark hair, squared jaw
- Black fight shorts with red accent stripe, bare chest, bull tattoo left shoulder
- Black fingerless MMA gloves
- Standing in low athletic wrestling stance, knees slightly bent
- Hands up at chin level, open palms ready to grip
- Weight on balls of feet, coiled and ready
- Confident, intense expression — ready to engage
```

### B2 — Yuki Idle Stance
```
[STYLE PREFIX]

Single fighter in relaxed fighting stance:
- Lean wiry build (5'8", 155 lbs), long limbs relative to torso
- Japanese, light skin, messy medium-length black hair, sharp features
- Navy compression rash guard with spider web pattern on sleeves
- Navy fight shorts with white side panels
- Black fingerless MMA gloves
- Standing tall in open guard-puller stance, one hand forward reaching, one back
- Weight balanced, light on feet, ready to move laterally
- Calm, analytical expression — studying opponent
```

### B3 — Marcus Victory
```
[STYLE PREFIX]

Single fighter in VICTORY celebration pose:
- Stocky heavyweight, Latino, medium-brown skin, buzzed dark hair
- Black fight shorts red stripe, bare chest, bull tattoo left shoulder
- Standing tall, both fists raised overhead triumphantly
- Head tilted back slightly, intense victorious expression
- Muscular chest puffed out, dominant powerful stance
- Like a champion celebrating a submission win
```

### B4 — Yuki Victory
```
[STYLE PREFIX]

Single fighter in VICTORY celebration pose:
- Lean wiry build, Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Standing with one arm raised, index finger pointing up (#1)
- Slight confident smile, composed even in victory
- Other hand on hip or adjusting rash guard casually
- Cool, collected champion energy — calm dominance
```

### B5 — Marcus Defeat
```
[STYLE PREFIX]

Single fighter in DEFEAT pose (just tapped out):
- Stocky heavyweight, Latino, medium-brown skin, buzzed dark hair
- Black fight shorts red stripe, bare chest, bull tattoo left shoulder
- Sitting on the ground, one knee up, head down in disappointment
- One hand on the mat behind for support, other hand on knee
- Exhausted, sweaty, dejected but not broken — warrior's loss
- Frustrated expression, looking at the ground
```

### B6 — Yuki Defeat
```
[STYLE PREFIX]

Single fighter in DEFEAT pose (just tapped out):
- Lean wiry build, Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Lying on back, forearm draped across forehead in exhaustion
- One leg bent, other extended flat
- Eyes closed, processing the loss — quiet disappointment
- Hair splayed, showing the toll of the fight
```

### B7 — Marcus Submission Attack (Arm)
```
[STYLE PREFIX]

Single fighter celebrating/executing an ARMBAR submission:
- Stocky heavyweight, Latino, medium-brown skin, buzzed dark hair
- Black fight shorts red stripe, bare chest, bull tattoo left shoulder
- On his back, hips thrust upward, both hands gripping an invisible arm
- Legs would be across opponent's chest (show them extended/squeezing)
- Face showing intense effort — teeth gritted, pulling hard
- Classic armbar extension posture from attacker's perspective
```

### B8 — Marcus Submission Attack (Choke)
```
[STYLE PREFIX]

Single fighter executing a REAR NAKED CHOKE grip:
- Stocky heavyweight, Latino, medium-brown skin, buzzed dark hair
- Black fight shorts red stripe, bare chest, bull tattoo left shoulder
- Seated position, arms extended forward in RNC grip
- Choking arm: bicep against invisible neck, forearm across invisible throat
- Other hand clasped behind the head position, squeezing
- Face showing controlled intensity — the squeeze is ON
- Body leaning back, pulling the choke tight
```

### B9 — Yuki Submission Attack (Arm)
```
[STYLE PREFIX]

Single fighter executing a TRIANGLE CHOKE setup:
- Lean wiry build, Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- On their back, legs up and crossed in triangle position
- One leg over invisible opponent's neck, other leg locked over the ankle
- Hands pulling down on invisible head, hips elevated
- Calm focused expression — methodical technique
- Long legs clearly visible in the triangle lock position
```

### B10 — Yuki Submission Attack (Choke)
```
[STYLE PREFIX]

Single fighter executing a GUILLOTINE CHOKE grip:
- Lean wiry build, Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Standing or kneeling, arms wrapped in guillotine grip
- One arm under and around invisible neck, other hand clasping own wrist
- Pulling upward with the choke, hips driving forward
- Intense but controlled expression — spider trapping prey
```

### B11 — Marcus Stunned/Rocked
```
[STYLE PREFIX]

Single fighter in STUNNED state (caught in a bad position):
- Stocky heavyweight, Latino, medium-brown skin, buzzed dark hair
- Black fight shorts red stripe, bare chest, bull tattoo left shoulder
- Staggering slightly, one hand reaching forward for balance
- Other hand on own head/temple area, dazed expression
- Stars or dizzy effect around head (classic fighting game stunned look)
- Knees wobbling, about to be in trouble
```

### B12 — Yuki Stunned/Rocked
```
[STYLE PREFIX]

Single fighter in STUNNED state (caught in a bad position):
- Lean wiry build, Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Bent forward slightly, hands on knees catching breath
- Hair hanging over face, exhausted and vulnerable
- Stars or dizzy effect around head
- Clearly in trouble but still standing — hanging on
```

### B13 — Marcus Walkout/Entrance
```
[STYLE PREFIX]

Single fighter in confident WALKOUT pose entering the arena:
- Stocky heavyweight, Latino, medium-brown skin, buzzed dark hair
- Black fight shorts red stripe, bare chest, bull tattoo left shoulder
- Walking forward with purpose, mid-stride
- One fist clenched and held up, other arm swinging
- Head up, eyes forward, intimidating stare
- Powerful confident stride — the bull entering the ring
```

### B14 — Yuki Walkout/Entrance
```
[STYLE PREFIX]

Single fighter in calm WALKOUT pose entering the arena:
- Lean wiry build, Japanese, light skin, messy black hair
- Navy rash guard spider web sleeves, navy shorts white panels
- Walking forward with measured pace, relaxed stride
- Arms loose at sides, rolling wrists/cracking knuckles casually
- Slight head tilt, analytical gaze — sizing up the arena
- Quiet confidence — the spider approaching its web
```

---

## SECTION C: OPTIONAL ENHANCEMENT SPRITES

### C1–C8: Idle Micro-Variations (Breathing)
For each of the 8 paired positions (A1–A8), generate ONE slight variation:
```
[Paste the exact same prompt as the original position, then add:]

VARIATION: This is a slight micro-movement variation of the settled position.
Make ONE subtle change: a slight shift in grip position, a small head turn,
or minimal weight adjustment. The overall position must remain the same —
this is a breathing/idle frame, not a transition to a different position.
Everything else identical to the base position.
```

### C9–C12: Submission Finish Close-Ups
```
Create a CPS2 Capcom arcade-style pixel art CLOSE-UP sprite showing a submission
finish in no-gi Brazilian Jiu-Jitsu. Zoomed in tighter than normal sprite — showing
upper body detail of the submission lock. Bold outlines, dramatic, 16-bit pixel art.
Transparent background.

[Then specify one of:]
- Armbar finish: Bottom fighter's arm fully extended, top fighter's hips thrusting up, arm hyperextended
- Rear Naked Choke finish: Arms tight around neck, choking arm deep, defender's face showing distress
- Triangle Choke finish: Legs locked tight around neck and one arm, squeezing, attacker pulling head down
- Guillotine finish: Standing guillotine locked tight, arm crushed under chin, attacker lifting up
```

---

## GENERATION TIPS

1. **Generate each prompt 3–5 times** — ChatGPT's image gen varies significantly between attempts. Pick the one with the cleanest contact points and best readability.

2. **If contact points have gaps**, add to the prompt: "Make sure there is ZERO visual gap between the fighters' bodies at all contact points. Their bodies should overlap and press together realistically."

3. **If the style drifts too modern/smooth**, add: "Keep the pixel art chunky and retro — visible individual pixels, limited color palette of 16-24 colours maximum, dithering for shading."

4. **If proportions are inconsistent**, re-paste the full character lock description. ChatGPT tends to drift after several generations.

5. **If the perspective is wrong** (top-down, front-on), emphasise: "Side-on 3/4 view as seen in a 2D fighting game, camera at character waist height looking horizontally."

6. **Save every generated image** even rejected ones — you may want to combine the best elements later.

7. **Name files clearly**: `A1_closed_guard_v1.png`, `A1_closed_guard_v2.png`, etc.
