# LOCKDOWN — Complete Sprite Production Plan
## Step-by-Step Guide

---

## Overview

This plan replaces the current approach of generating individual character sprites with a **paired composition pipeline** — generating both fighters together, then using AI-assisted tools to separate and align them. This ensures grappling positions look physically correct.

**Total new cost**: $19.99 (Aseprite, optional — free alternatives available)
**Total time estimate**: 12–18 hours
**Manual work**: ~2 hours of review/touchup (down from ~8 hours)

---

## What You'll Need Before Starting

| Item | Status | Notes |
|------|--------|-------|
| ChatGPT Plus subscription | ✅ Already have | Image generation |
| Claude subscription | ✅ Already have | Code + prompts |
| Python 3.9+ installed | Check: `python3 --version` | For pipeline scripts |
| Node.js installed | ✅ Already have | For game engine |
| Aseprite ($19.99) | Optional | Only if auto-separation needs manual fixes |
| Photopea (free) | Browser-based | Free alternative to Aseprite |

### Python Setup (One-Time)
```bash
pip install Pillow numpy scikit-learn scipy
```

---

## STEP 1: Review Character Descriptions (15 minutes)

Open the file: **`prompts/ALL_PROMPTS.md`**

At the top you'll find CHARACTER LOCK descriptions for Marcus and Yuki. **Before generating anything**, compare these descriptions against your existing sprites from our previous sessions. If any detail is wrong (shorts colour, hair length, skin tone, rash guard colour), update the character lock — it gets copy-pasted into every prompt.

Key things to verify:
- Marcus's skin tone matches your existing sprites
- Yuki's rash guard colour and pattern match
- Both characters' build/proportions match what you've already generated
- Fight shorts colours and details are consistent

**Once verified, move to Step 2. Do not generate until descriptions are locked.**

---

## STEP 2: Generate Paired Grappling Sprites (3–4 hours)

Open ChatGPT. You'll generate 8 paired compositions — one for each grappling position.

### Process for Each Position:

1. **Copy the full prompt** from `prompts/ALL_PROMPTS.md` (Section A, prompts A1–A8)
2. **Paste into ChatGPT** and generate
3. **Evaluate the result** against these criteria:
   - ✅ Both characters clearly visible and distinguishable
   - ✅ Contact points connected — no gaps between bodies where they should touch
   - ✅ Correct BJJ position (e.g., guard has legs wrapped, mount has top player seated)
   - ✅ CPS2 pixel art style — visible pixels, limited palette, bold outlines
   - ✅ Transparent background
   - ✅ Side-on 3/4 perspective
4. **If it doesn't meet criteria**, re-generate. Use the troubleshooting tips at the bottom of the prompts file.
5. **Save the best result** with the naming convention:
   - `A1_closed_guard.png`
   - `A2_open_guard.png`
   - `A3_half_guard.png`
   - `A4_side_control.png`
   - `A5_mount.png`
   - `A6_back_mount.png`
   - `A7_turtle.png`
   - `A8_standing_clinch.png`

### Then Generate Solo Sprites:

6. **Copy each prompt** from Section B (B1–B14) and generate in ChatGPT
7. **Save with naming convention**:
   - `B1_marcus_idle.png`
   - `B2_yuki_idle.png`
   - `B3_marcus_victory.png`
   - ... etc.

### Tips:
- Budget 3–5 attempts per position for paired sprites
- Solo sprites usually work in 1–2 attempts
- If ChatGPT starts producing inconsistent styles mid-session, start a new conversation and re-paste the character locks
- Save ALL generated images (even rejected ones) in a `raw/` subfolder — you might want them later

### Output from this step:
```
raw_sprites/
├── A1_closed_guard.png
├── A2_open_guard.png
├── A3_half_guard.png
├── A4_side_control.png
├── A5_mount.png
├── A6_back_mount.png
├── A7_turtle.png
├── A8_standing_clinch.png
├── B1_marcus_idle.png
├── B2_yuki_idle.png
├── B3_marcus_victory.png
├── B4_yuki_victory.png
├── B5_marcus_defeat.png
├── B6_yuki_defeat.png
├── B7_marcus_sub_arm.png
├── B8_marcus_sub_choke.png
├── B9_yuki_sub_arm.png
├── B10_yuki_sub_choke.png
├── B11_marcus_stunned.png
├── B12_yuki_stunned.png
├── B13_marcus_walkout.png
└── B14_yuki_walkout.png
```

---

## STEP 3: Calibrate the Separator (30 minutes)

Before batch-processing, test with ONE sprite to calibrate the color palette matching.

### 3a. Test with a single paired sprite:
```bash
python scripts/separate_sprites.py raw_sprites/A5_mount.png \
  --output-dir test_separation/ \
  --position mount
```

### 3b. Check the output:
- Open `test_separation/mount_debug.png` — this shows the separation with colours tinted:
  - **Red tint** = pixels assigned to Marcus
  - **Blue tint** = pixels assigned to Yuki
  - **Green dots** = detected anchor/contact points
- Open `test_separation/mount_marcus.png` and `mount_yuki.png` — the separated sprites

### 3c. Evaluate:

**If separation looks good** (>80% of pixels correctly assigned):
→ Move to Step 4

**If separation is messy** (characters blended or wrong pixels assigned):
→ Open `scripts/separate_sprites.py` and adjust the `CHARACTER_PALETTES` section at the top:

```python
CHARACTER_PALETTES = {
    "marcus": {
        "signature_colors": [
            # Sample actual pixel colors from your Marcus sprites
            # Use an eyedropper tool in any image editor
            (R, G, B),  # His exact skin tone
            (R, G, B),  # His exact shorts color
            (R, G, B),  # His exact red stripe color
        ],
        "color_tolerance": 50,  # Increase to be more lenient, decrease for stricter
    },
    ...
}
```

**How to sample colors**: Open any generated sprite in Photopea (free, browser-based). Use the eyedropper tool to click on Marcus's skin, shorts, and stripe. Note the RGB values. Do the same for Yuki's rash guard, skin, and shorts. Paste those exact values into the script.

Re-run and check again. Repeat until the debug image shows clean separation.

---

## STEP 4: Batch Process All Paired Sprites (10 minutes)

Once calibration looks good:

```bash
python scripts/separate_sprites.py raw_sprites/ \
  --output-dir separated/ \
  --batch
```

This processes all `A*.png` files and outputs:
```
separated/
├── closed_guard/
│   ├── closed_guard_marcus.png
│   ├── closed_guard_yuki.png
│   ├── closed_guard_anchors.json
│   └── closed_guard_debug.png
├── open_guard/
│   ├── open_guard_marcus.png
│   ├── open_guard_yuki.png
│   ├── open_guard_anchors.json
│   └── open_guard_debug.png
├── ... (6 more positions)
└── anchor_manifest.json    ← Combined data for the game engine
```

---

## STEP 5: Verify with Preview Sheet (15 minutes)

Generate a visual preview of all separations:

```bash
python scripts/preview_anchors.py separated/ \
  --output preview_sheet.png
```

This creates a single image showing every position three ways:
1. **OVERLAY** — both sprites layered (should look like the original)
2. **MARCUS** — his sprite alone
3. **YUKI** — her sprite alone

Also generate the anchor verification view:
```bash
python scripts/preview_anchors.py separated/ \
  --output anchor_sheet.png \
  --anchors-only
```

### What to check:
- ✅ Overlays look like complete grappling positions (no missing body parts)
- ✅ Individual sprites have clean edges (no chunks of the other character)
- ✅ Anchor points (green markers) are at actual contact points (hips, grips, shoulders)
- ✅ No position has wildly uneven split (one character shouldn't be 90% of pixels)

### If something's off:

**Option A — Re-run separator with adjusted palettes** (go back to Step 3c)

**Option B — Manual touchup in Aseprite or Photopea**:
1. Open the separated sprite in Photopea (free) or Aseprite ($19.99)
2. Use eraser to remove stray pixels from the wrong character
3. Use pencil to fill in any missing pixels
4. Save over the separated file
5. You do NOT need to re-run the pipeline — just fix the PNG

**Option C — Regenerate that position** (go back to Step 2, that specific prompt only)

---

## STEP 6: Integrate into Game Engine (2–3 hours, Claude-assisted)

### 6a. Copy assets into your game project:
```bash
# Copy separated sprites
cp -r separated/ your-game-project/sprites/

# Copy solo sprites
cp raw_sprites/B*.png your-game-project/sprites/solo/

# Copy the manifest
cp separated/anchor_manifest.json your-game-project/sprites/
```

### 6b. Integrate the anchor renderer:

The file `scripts/anchor_renderer.js` contains the complete rendering system. You have two integration options:

**Option 1 — Embed in your existing JSX artifact**:
Copy the `SpriteCache`, `PositionRenderer`, and `initSpriteSystem` classes directly into your game code. Wire them up to your existing position state management.

**Option 2 — Ask Claude to integrate it**:
Share your current game artifact with Claude along with the `anchor_manifest.json` and ask:
> "Integrate this anchor-based sprite rendering system into my LOCKDOWN game.
> Here's the manifest JSON and the renderer code. Replace the current sprite
> rendering with this system. Keep all existing gameplay, transitions, and
> effects — just swap how the character sprites are loaded and positioned."

### 6c. Convert sprites to base64 (for single-file artifact):

If your game is a single-file React artifact, you'll need sprites as base64.
Ask Claude to write a quick conversion script, or:

```bash
# Convert a sprite to base64 string
base64 -i separated/mount/mount_marcus.png | tr -d '\n'
```

### 6d. Wire up transitions:

Your existing transition system (screen shake, overlays, text banners) stays exactly as-is. The only change is what happens during the transition:

**Before**: Swap individual character CSS positions/transforms
**After**: Call `renderer.renderPosition(newPosition, topChar, bottomChar)`

The flash/shake hides the swap. The new sprites appear already perfectly aligned.

---

## STEP 7: Test All Combinations (1–2 hours)

Go through every game position and verify:

| Test | What to Check |
|------|---------------|
| Marcus top vs Yuki bottom (all 8 positions) | Sprites aligned, no gaps |
| Yuki top vs Marcus bottom (all 8 positions) | Roles swap correctly |
| Transition from each position to every other | Screen shake covers swap cleanly |
| Solo states (idle, victory, defeat) | Display correctly |
| Submission finishes | Close-up sprites trigger correctly |
| AI opponent plays full match | No visual glitches across all transitions |

### If anchor alignment is slightly off in a specific position:
Open the relevant `*_anchors.json` file and adjust the `center_x` / `center_y` values by a few pixels. These are just coordinates — nudge them until the overlay looks right. No code changes needed.

---

## STEP 8: Optional Polish (2–4 hours if desired)

### Idle Micro-Animations
Generate 1 variation per paired position using the C1–C8 prompts in the prompts file. This gives settled positions a subtle breathing/shifting animation instead of being static.

Process: Same pipeline (generate → separate → integrate), just with 2 frames per position instead of 1.

### Submission Close-Ups
Generate 4–6 dramatic close-up sprites using prompts C9–C12. These display during the "SUBMISSION!" screen overlay for extra impact.

### Colour-Swap Characters
For your alt-colour/mirror match feature, you can generate palette-swapped versions by adding to the prompt: "Same character but with [different colour] shorts and [different colour] skin tone" — or use Aseprite/Photopea's palette swap tool on the separated sprites.

---

## Cost Summary

| Item | Cost | Status |
|------|------|--------|
| ChatGPT Plus | $20/month | Already subscribed |
| Claude Pro | $20/month | Already subscribed |
| Aseprite | $19.99 one-time | Optional — only if manual touchup needed |
| Photopea | Free | Browser-based alternative to Aseprite |
| Python + libraries | Free | Pillow, numpy, scikit-learn, scipy |
| Piskel | Free | Optional animation preview |

**New spend required: $0–$19.99**

---

## Time Summary

| Step | Time | AI vs Manual |
|------|------|-------------|
| 1. Review character descriptions | 15 min | Manual |
| 2. Generate all sprites in ChatGPT | 3–4 hrs | AI generation, manual curation |
| 3. Calibrate separator | 30 min | Manual (one-time) |
| 4. Batch process separations | 10 min | Automated |
| 5. Verify preview sheets | 15 min | Manual review |
| 6. Integrate into game engine | 2–3 hrs | Claude-assisted |
| 7. Test all combinations | 1–2 hrs | Manual play-testing |
| 8. Optional polish | 2–4 hrs | AI + manual |
| **Total** | **~10–14 hrs** | **~80% AI-assisted** |

---

## File Inventory

```
lockdown-pipeline/
├── docs/
│   └── (this plan)
├── prompts/
│   └── ALL_PROMPTS.md          ← All ChatGPT prompts (Sections A, B, C)
├── scripts/
│   ├── separate_sprites.py     ← AI sprite separation pipeline
│   ├── preview_anchors.py      ← Visual verification tool
│   └── anchor_renderer.js      ← Game engine integration code
├── raw_sprites/                ← (you create) Generated images from ChatGPT
├── separated/                  ← (auto-generated) Separated sprites + anchors
└── README.md                   ← Quick reference
```

---

## Quick Reference Commands

```bash
# Install Python dependencies
pip install Pillow numpy scikit-learn scipy

# Test separation on one sprite
python scripts/separate_sprites.py raw_sprites/A5_mount.png -o test/ -p mount

# Batch process all paired sprites
python scripts/separate_sprites.py raw_sprites/ -o separated/ --batch

# Generate preview sheet
python scripts/preview_anchors.py separated/ -o preview_sheet.png

# Generate anchor verification sheet
python scripts/preview_anchors.py separated/ -o anchor_sheet.png --anchors-only
```

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Separator assigns most pixels to one character | Adjust `CHARACTER_PALETTES` RGB values in `separate_sprites.py` — sample actual colours from your sprites with an eyedropper |
| Separator splits character in half | Increase `color_tolerance` value (try 60–80) |
| Generated sprite has wrong BJJ position | Add more detail to the CRITICAL CONTACT POINTS section of the prompt |
| Characters look disconnected in generated image | Add to prompt: "Bodies pressing together with zero visual gap at all contact points" |
| Style drifts from CPS2 look | Start a new ChatGPT conversation and re-paste the full style lock |
| Anchor points are in wrong location | Manually edit the `*_anchors.json` file — adjust center_x/center_y values |
| Sprites look blurry when scaled up | Ensure `imageSmoothingEnabled = false` in canvas context (the renderer does this) |
| Base64 encoding makes file too large | Use WebP format instead of PNG: `cwebp input.png -o output.webp` |
